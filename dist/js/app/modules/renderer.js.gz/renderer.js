import {
  $, addClass, removeClass, copyText, escapeHtml, formatDate, formatUserText,
} from "../utils.js";

export class Renderer {
  constructor(options) {
    this.options = options;
    this.statusRegion = $("ariaStatus");
    this.loadingTemplate = $("loading")?.innerHTML || "";
  }

  showLoading() {
    const loading = $("loading");
    const grid = $("userList");
    if (loading) {
      if (this.loadingTemplate && !loading.innerHTML.includes("skeleton-card")) {
        loading.innerHTML = this.loadingTemplate;
      }
      loading.classList.add("skeleton-grid");
      loading.classList.remove("text-center");
      removeClass(loading, "hidden");
    }
    if (grid) addClass(grid, "hidden");
  }

  hideLoading() {
    const loading = $("loading");
    if (loading) addClass(loading, "hidden");
  }

  showError(message) {
    const loading = $("loading");
    const grid = $("userList");
    const noResults = $("noResults");

    if (grid) addClass(grid, "hidden");
    if (noResults) addClass(noResults, "hidden");

    if (loading) {
      loading.classList.remove("skeleton-grid");
      loading.classList.add("text-center");
      removeClass(loading, "hidden");
      loading.innerHTML = `<p style="color:#ef4444;font-weight:500;">${escapeHtml(message)}</p>`;
    }
    if (this.statusRegion) this.statusRegion.textContent = message;
  }

  renderUsers(users) {
    const container = $("userList");
    const noResults = $("noResults");
    if (!container || !noResults) return;

    if (!users.length) {
      addClass(container, "hidden");
      removeClass(noResults, "hidden");
      return;
    }

    removeClass(container, "hidden");
    addClass(noResults, "hidden");
    container.innerHTML = "";

    users.forEach((user) => {
      container.appendChild(this.createUserCard(user));
    });
  }

  createUserCard(user) {
    const card = document.createElement("div");
    card.className = `card card-hover fade-in relative${user.urgent ? " urgent" : ""}`;
    card.setAttribute("role", "listitem");

    const urgentBadge = user.urgent ? '<div class="urgent-badge">URGENT</div>' : "";
    const genderText = user.gender === "female" ? "لڑکی" : user.gender === "male" ? "لڑکا" : "";
    const displayTitle = user.title || `ضرورت رشتہ ${genderText}`;

    card.innerHTML = `
      ${urgentBadge}
      <h2 class="font-urdu text-lg font-semibold card-title-urdu">${formatUserText(displayTitle)}</h2>
      <p class="font-urdu text-gray-700 card-body-urdu">${formatUserText(user.body || "")}</p>
      <div class="card-meta">
        <small>LR ID: ${escapeHtml(String(user.id))}</small>
        <small>Date: ${escapeHtml(formatDate(user.date))}</small>
      </div>
      <div class="card-actions card-actions-primary">
        <button class="action-btn action-btn-lg contact-btn" data-id="${escapeHtml(String(user.id))}" aria-label="Contact on WhatsApp">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"></path>
          </svg>
          <span>Contact</span>
        </button>
        <button class="action-btn action-btn-lg call-btn" data-id="${escapeHtml(String(user.id))}" aria-label="Call profile">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
          </svg>
          <span>Call</span>
        </button>
      </div>
    `;

    card.querySelector(".contact-btn")?.addEventListener("click", (event) => {
      event.preventDefault();
      this.options.onContact(user);
    });

    card.querySelector(".call-btn")?.addEventListener("click", (event) => {
      event.preventDefault();
      this.options.onCall(user);
    });

    this.attachCardGestures(card, user);
    return card;
  }

  attachCardGestures(card, user) {
    const hasActionTarget = (target) =>
      Boolean(target && target.closest && target.closest(".action-btn"));

    let lastTapAt = 0;
    let longPressTimer = null;
    let longPressTriggered = false;
    let startX = 0;
    let startY = 0;
    let moved = false;

    const clearLongPress = () => {
      if (!longPressTimer) return;
      clearTimeout(longPressTimer);
      longPressTimer = null;
    };

    card.addEventListener(
      "touchstart",
      (event) => {
        if (hasActionTarget(event.target)) return;

        const touch = event.touches[0];
        if (!touch) return;
        startX = touch.clientX;
        startY = touch.clientY;
        moved = false;
        longPressTriggered = false;
        clearLongPress();

        longPressTimer = setTimeout(() => {
          longPressTriggered = true;
          if (navigator.vibrate) navigator.vibrate(18);
          this.options.onLongPress?.(user);
        }, 600);
      },
      { passive: true }
    );

    card.addEventListener(
      "touchmove",
      (event) => {
        if (!longPressTimer) return;
        const touch = event.touches[0];
        if (!touch) return;
        const deltaX = Math.abs(touch.clientX - startX);
        const deltaY = Math.abs(touch.clientY - startY);
        if (deltaX > 12 || deltaY > 12) {
          moved = true;
          clearLongPress();
        }
      },
      { passive: true }
    );

    card.addEventListener(
      "touchend",
      (event) => {
        if (hasActionTarget(event.target)) {
          clearLongPress();
          return;
        }

        clearLongPress();
        if (moved || longPressTriggered) return;

        const now = Date.now();
        if (now - lastTapAt < 320) {
          lastTapAt = 0;
          if (navigator.vibrate) navigator.vibrate(10);
          this.options.onShare?.(user);
          return;
        }

        lastTapAt = now;
      },
      { passive: true }
    );

    card.addEventListener(
      "touchcancel",
      () => {
        moved = false;
        longPressTriggered = false;
        clearLongPress();
      },
      { passive: true }
    );

    card.addEventListener("dblclick", (event) => {
      if (hasActionTarget(event.target)) return;
      event.preventDefault();
      this.options.onShare?.(user);
    });

    card.addEventListener("contextmenu", (event) => {
      if (hasActionTarget(event.target)) return;
      event.preventDefault();
      this.options.onLongPress?.(user);
    });
  }

  async handleCopyId(id) {
    const ok = await copyText(`LR${id}`);
    this.showToast(ok ? "ID copied to clipboard!" : "Could not copy ID");
  }

  async shareUserCard(user) {
    const blob = await this.createUserCardImageBlob(user);
    const fileName = `InstaRishta-LR${user.id}.png`;

    const file =
      typeof File !== "undefined"
        ? new File([blob], fileName, { type: "image/png" })
        : null;

    if (
      navigator.share &&
      navigator.canShare &&
      file &&
      navigator.canShare({ files: [file] })
    ) {
      try {
        await navigator.share({
          title: `InstaRishta LR ${user.id}`,
          text: `LR ID: ${user.id}`,
          files: [file],
        });
        this.showToast("Card shared");
        return;
      } catch (error) {

        if (error && error.name === "AbortError") return;
      }
    }

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    this.showToast("Image downloaded for sharing");
  }

  async createUserCardImageBlob(user) {
    const canvas = document.createElement("canvas");
    const width = 1080;
    const height = 1350;
    canvas.width = width;
    canvas.height = height;

    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Canvas context unavailable");

    const background = ctx.createLinearGradient(0, 0, width, height);
    background.addColorStop(0, "#4f46e5");
    background.addColorStop(1, "#7c3aed");
    ctx.fillStyle = background;
    ctx.fillRect(0, 0, width, height);

    this.drawRoundedRect(ctx, 70, 90, width - 140, height - 180, 34, "#ffffff");

    ctx.fillStyle = "#1f2937";
    ctx.font = "700 54px Inter, Arial, sans-serif";
    ctx.fillText("InstaRishta", 120, 190);

    ctx.fillStyle = "#4f46e5";
    ctx.font = "700 64px Inter, Arial, sans-serif";
    ctx.fillText(`LR ID: ${user.id}`, 120, 290);

    ctx.fillStyle = "#111827";
    ctx.font = "600 42px Inter, Arial, sans-serif";
    let currentY = this.drawWrappedText(
      ctx,
      user.title || "Profile",
      120,
      380,
      width - 240,
      54,
      3
    );

    ctx.fillStyle = "#374151";
    ctx.font = "400 34px Inter, Arial, sans-serif";
    currentY = this.drawWrappedText(
      ctx,
      user.body || "",
      120,
      currentY + 20,
      width - 240,
      46,
      12
    );

    ctx.fillStyle = "#6b7280";
    ctx.font = "500 30px Inter, Arial, sans-serif";
    ctx.fillText(`Date: ${formatDate(user.date)}`, 120, Math.min(currentY + 70, 1130));

    ctx.fillStyle = "#111827";
    ctx.font = "600 28px Inter, Arial, sans-serif";
    ctx.fillText("instarishta.me", width - 330, height - 90);

    return new Promise((resolve, reject) => {
      canvas.toBlob(
        (blob) => {
          if (!blob) {
            reject(new Error("Could not render share image"));
            return;
          }
          resolve(blob);
        },
        "image/png",
        0.95
      );
    });
  }

  drawRoundedRect(ctx, x, y, width, height, radius, fillStyle) {
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + width - radius, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
    ctx.lineTo(x + width, y + height - radius);
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
    ctx.lineTo(x + radius, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
    ctx.fillStyle = fillStyle;
    ctx.fill();
  }

  drawWrappedText(ctx, text, x, y, maxWidth, lineHeight, maxLines) {
    const words = String(text || "").replace(/\s+/g, " ").trim().split(" ");
    const lines = [];
    let line = "";

    for (let i = 0; i < words.length; i += 1) {
      const word = words[i];
      const testLine = line ? `${line} ${word}` : word;
      const width = ctx.measureText(testLine).width;
      if (width > maxWidth && line) {
        lines.push(line);
        line = word;
      } else {
        line = testLine;
      }

      if (lines.length === maxLines) break;
    }

    if (line && lines.length < maxLines) {
      lines.push(line);
    }

    if (words.length && lines.length === maxLines) {
      const last = lines[maxLines - 1];
      if (last && !last.endsWith("...")) {
        lines[maxLines - 1] = `${last.slice(0, Math.max(0, last.length - 3))}...`;
      }
    }

    lines.forEach((entry, index) => {
      ctx.fillText(entry, x, y + lineHeight * index);
    });

    return y + lineHeight * lines.length;
  }

  updateStatistics(filteredUsers) {
    const totalElement = $("totalAds");
    const maleElement = $("maleProfiles");
    const femaleElement = $("femaleProfiles");
    const urgentElement = $("urgentAds");

    const total = filteredUsers.length;
    const male = filteredUsers.filter((u) => u.gender === "male").length;
    const female = filteredUsers.filter((u) => u.gender === "female").length;
    const urgent = filteredUsers.filter((u) => u.urgent).length;

    if (totalElement) totalElement.textContent = String(total);
    if (maleElement) maleElement.textContent = String(male);
    if (femaleElement) femaleElement.textContent = String(female);
    if (urgentElement) urgentElement.textContent = String(urgent);
  }

  updateFilterChips(appliedFilters, onRemove) {
    const container = $("filterChips");
    if (!container) return;

    container.querySelectorAll(".filter-chip").forEach((chip) => chip.remove());

    if (!appliedFilters.length) {
      container.style.display = "none";
      return;
    }

    container.style.display = "flex";

    appliedFilters.forEach((filter) => {
      const chip = document.createElement("div");
      chip.className = "filter-chip";
      chip.innerHTML = `
        <span class="chip-label">${escapeHtml(filter.name)}: ${escapeHtml(filter.value)}</span>
        <button class="chip-close" data-filter="${escapeHtml(filter.name)}">&times;</button>
      `;

      chip.querySelector(".chip-close")?.addEventListener("click", () => onRemove(filter.name));
      container.appendChild(chip);
    });
  }

  updateContactLimitIndicator(remaining, resetText) {
    const indicator = $("contactLimitIndicator");
    const remainingElement = $("remainingContacts");
    const timerElement = $("resetTimer");

    if (!indicator || !remainingElement || !timerElement) return;

    remainingElement.textContent = String(remaining);

    if (remaining === 0) {
      timerElement.textContent = `Resets in ${resetText}`;
      indicator.style.background = "linear-gradient(135deg, #fef2f2, #fee2e2)";
      indicator.style.borderColor = "#ef4444";
      remainingElement.style.color = "#dc2626";
    } else if (remaining <= 3) {
      timerElement.textContent = `Resets in ${resetText}`;
      indicator.style.background = "linear-gradient(135deg, #fffbeb, #fef3c7)";
      indicator.style.borderColor = "#f59e0b";
      remainingElement.style.color = "#d97706";
    } else {
      timerElement.textContent = "Resets every hour";
      indicator.style.background = "linear-gradient(135deg, #f0f9ff, #e0f2fe)";
      indicator.style.borderColor = "#0ea5e9";
      remainingElement.style.color = "#0284c7";
    }
  }

  showToast(message) {
    const toast = document.createElement("div");
    toast.style.cssText =
      "position:fixed;top:20px;right:20px;background:#333;color:#fff;padding:12px 16px;border-radius:8px;z-index:10000;font-size:14px;";
    toast.textContent = message;
    document.body.appendChild(toast);
    if (this.statusRegion) this.statusRegion.textContent = message;

    setTimeout(() => {
      toast.remove();
    }, 2200);
  }
}